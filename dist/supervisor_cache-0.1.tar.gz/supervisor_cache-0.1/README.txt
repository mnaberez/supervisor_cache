supervisor_cache:
  This package is an RPC extension for the Supervisor package 
  that provides the ability to cache abritrary data in a 
  Supervisor instance as key/value pairs.
      
Home Page
  "supervisor_cache":http://maintainable.com/software/supervisor_cache
  
Author Information

  Mike Naberezny (mike@maintainable.com)
  "Maintainable Software":http://www.maintainable.com
